﻿// -------------------------------------------
// Control Freak 2
// Copyright (C) 2013-2018 Dan's Game Tools
// http://DansGameTools.blogspot.com
// -------------------------------------------


//! \cond

using UnityEngine;

namespace ControlFreak2
{

public class BuiltInGamepadProfileBankLinux : BuiltInGamepadProfileBank
	{
	// ------------------
	public BuiltInGamepadProfileBankLinux() : base()
		{
		this.profiles = new GamepadProfile[]
			{	
			};
		}
	}
}

//! \endcond
