﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    [SerializeField]
    private float MoveForce = 10f;
    [SerializeField]
    private float JumpForce = 11f;

    private float MovementX;

    private Rigidbody2D Mybody;
    private SpriteRenderer sr;
    private Animator anim;
    private string WALK_ANIMATION = "Walk";

    private bool isGrounded;
    private string GROUND_TAG = "Ground";

    private string ENEMY_TAG = "Enemy";
    // Start is called before the first frame update
    private void Awake()
    {
        Mybody = GetComponent<Rigidbody2D>();
        sr = GetComponent<SpriteRenderer>();
        anim = GetComponent<Animator>();
    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        PlayerMoveKeyboard();
        AnimatePlayer();
    }

    private void FixedUpdate()
    {
        PlayerJump();
    }
    void PlayerMoveKeyboard()
    {
        MovementX = ControlFreak2.CF2Input.GetAxisRaw("Horizontal");
        transform.position += new Vector3(MovementX,0f,0f) * Time.deltaTime * MoveForce;
    }

    void AnimatePlayer()
    {
        //anim.SetBool(WALK_ANIMATION, true);
        //sr.flipX = true;
        if (MovementX > 0)
        {

            anim.SetBool(WALK_ANIMATION, true);

            sr.flipX = false;
        }
        else if (MovementX < 0)
        {

            anim.SetBool(WALK_ANIMATION, true);

            sr.flipX = true;
        }
        else
        {
            anim.SetBool(WALK_ANIMATION, false);
        }
    }

    void PlayerJump()
    {
        if(ControlFreak2.CF2Input.GetButtonDown("Jump") && isGrounded)
        {
            
            Mybody.AddForce(new Vector2(0f, JumpForce), ForceMode2D.Impulse);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag(GROUND_TAG)) ;
        {
            isGrounded = true;
        }

        if(collision.gameObject.CompareTag(ENEMY_TAG))
        {
            Destroy(gameObject);
        }
    }

    //private void OnTriggerEnter2D(Collider2D collision)
    //{
    //    if (collision.CompareTag(ENEMY_TAG))
    //        Destroy(gameObject);
    //}
}
