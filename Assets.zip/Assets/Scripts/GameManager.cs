using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;
    [SerializeField]
    private GameObject[] Characters;

    private int IndexChar;
    public int CharIndex
    {
        get { return IndexChar; }
        set { IndexChar = value; }
    }

    private void Awake()
    {
        if(Instance==null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void OnEnable()
    {
        SceneManager.sceneLoaded += OnlevelFinishedLoading;
    }

    private void OnDisable()
    {
        SceneManager.sceneLoaded -= OnlevelFinishedLoading;
    }
    void OnlevelFinishedLoading(Scene scene,LoadSceneMode mode)
    {
        if(scene.name=="GamePlay")
        {
            Instantiate(Characters[CharIndex]);
        }
    }
}
