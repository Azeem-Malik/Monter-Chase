using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonsterSpawner : MonoBehaviour
{
    [SerializeField]
    private GameObject[] MonsterRefrence;

    [SerializeField]
    private Transform leftPos, rightPos;

    private GameObject SpawnedMonster;
    private int RandomIndex;
    private int RandomSide;
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(SpawneMonster());
    }

    IEnumerator SpawneMonster()
    {

        while (true)
        {
            yield return new WaitForSeconds(Random.Range(1, 5));
            RandomIndex = Random.Range(0, MonsterRefrence.Length);
            RandomSide = Random.Range(0, 2);
            SpawnedMonster = Instantiate(MonsterRefrence[RandomIndex]);

            if (RandomSide == 0)
            {
                SpawnedMonster.transform.position = leftPos.position;
                SpawnedMonster.GetComponent<Monster>().Speed = Random.Range(4, 19);
            }
            else
            {
                SpawnedMonster.transform.position = rightPos.position;
                SpawnedMonster.GetComponent<Monster>().Speed = -Random.Range(4, 10);
                SpawnedMonster.transform.localScale = new Vector3(-1f, 1f, 1f);
            }
        }
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
