using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Monster : MonoBehaviour
{
    [HideInInspector]
    public float Speed;

    private Rigidbody2D Mybody;
    // Start is called before the first frame update

    private void Awake()
    {
        Mybody = GetComponent<Rigidbody2D>();
        //Speed = 7f;
    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        Mybody.velocity = new Vector2(Speed, Mybody.velocity.y);
    }
}
